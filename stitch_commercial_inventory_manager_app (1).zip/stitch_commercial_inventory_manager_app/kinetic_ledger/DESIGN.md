---
name: Kinetic Ledger
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#464555'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#545f73'
  on-secondary: '#ffffff'
  secondary-container: '#d5e0f8'
  on-secondary-container: '#586377'
  tertiary: '#005338'
  on-tertiary: '#ffffff'
  tertiary-container: '#006e4b'
  on-tertiary-container: '#67f4b7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#d8e3fb'
  secondary-fixed-dim: '#bcc7de'
  on-secondary-fixed: '#111c2d'
  on-secondary-fixed-variant: '#3c475a'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
  metric-display:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 34px
  mono-data:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.25rem
  space-xl: 1.75rem
---

## Brand & Style

The design system establishes a high-performance, executive-grade mobile environment tailored for modern commerce directors, inventory architects, and operations leads managing mission-critical REST API data flows on the go. 

The aesthetic is anchored in contemporary Fintech precision paired with Enterprise SaaS utility. It rejects visual fluff in favor of razor-sharp density, intentional negative space, and instant legibility under high operational stress. By fusing clean surfaces with deep indigo infrastructure and functional status accents (emerald performance metrics, amber threshold warnings), the interface evokes absolute reliability, fluid control, and architectural rigor. 

Interaction feedback is subtle, tactile, and predictable—instilling trust during high-stakes inventory dispatches, bulk price mutations, and role-permission assignments.

## Colors

The system uses a calibrated tonal structure to distinguish between operational infrastructure and business performance data:

- **Primary (`#4F46E5` - Electric Indigo):** Drives core actionable moments, active navigation nodes, focused input states, and primary API trigger triggers.
- **Secondary (`#1E293B` - Deep Slate):** Anchors high-hierarchy data headers, modal anchor surfaces, contrast containers, and persistent enterprise boundaries.
- **Tertiary (`#10B981` - Emerald Growth):** Reserved strictly for positive financial telemetry, settled sales transactions, active sync signals, and healthy inventory counts.
- **Warning Accent (`#F59E0B` - Amber Alert):** Dedicated to stock thresholds, API rate-limit notifications, pending invoice queues, and degraded system states.
- **Critical / Danger (`#EF4444` - Crimson Guard):** Applied to destructive endpoints, stockouts, unauthenticated calls, and failed webhook dispatches.
- **Canvas & Neutrals (`#F8FAFC` to `#FFFFFF` with `#0F172A` text):** Ultra-crisp, cool-tinted paper backgrounds that maximize component separation and ensure AA/AAA WCAG compliance across harsh outdoor and variable indoor lighting.

## Typography

The typography leverages **Plus Jakarta Sans** for primary brand narrative and user interface interactions, bringing geometric confidence, open apertures, and excellent rhythm at micro-scales. 

Numerical integrity is essential: tabular figures (`tnum`) must be enforced on all financial cards, stock metrics, currency tickers, and timestamp nodes to prevent horizontal jitter during live Webhook/REST poll events. For technical parameters (API tokens, UUIDs, endpoint routes, JSON keys), the system seamlessly invokes **JetBrains Mono** at normalized line-heights to differentiate operational data strings from standard copy.

## Layout & Spacing

The layout is built for fluid mobile-first operations, adopting a dynamic 4-column structure on handheld viewports expanding to an 8-column canvas on compact tablets.

- **Vertical Cadence:** Built around an 8pt base grid with a 4pt sub-unit for compact badge padding, icon-to-label alignment, and list row delimiters.
- **Canvas Margins:** Fixed at `1rem` (16px) on mobile viewports under 400px width; opens to `1.25rem` (20px) on large handhelds to accommodate edge-swipe ergonomic buffers.
- **Gutter Distribution:** `1rem` (16px) consistent gutters between modular dashboard metric tiles.
- **Touch-Target Guarantee:** All interactive elements maintain an absolute minimum touch zone of 44×44pt, surrounded by minimum `space-xs` (4px) isolation to eliminate mis-taps during active floor inventory operations.

## Elevation & Depth

Visual hierarchy is maintained through calibrated surface layering and ambient micro-shadows rather than stark heavy outlines.

- **Base Canvas:** `#F8FAFC` flat structural plane.
- **Level 1 (Card & Module Layer):** `#FFFFFF` surface accompanied by a dual-tier ambient shadow: `0 1px 3px rgba(15, 23, 42, 0.04), 0 4px 12px rgba(15, 23, 42, 0.03)` with a subtle perimeter stroke (`1px solid #F1F5F9`).
- **Level 2 (Interactive Floating Elements, Dropdowns, Action Sheets):** `#FFFFFF` surface, `0 10px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.03)`, border tinted at `1px solid #E2E8F0`.
- **Level 3 (Modal Overlays, Persistent Bottom Drawers):** Backdrop-filter blur (`12px`) applied to an alpha-dimmed canvas (`rgba(15, 23, 42, 0.45)`), with the modal body anchored at `0 20px 30px -10px rgba(0, 0, 0, 0.2)`.

## Shapes

The design system implements balanced geometric curves that convey modern precision while remaining friendly to touch ergonomics:

- **Metrics & Content Containers:** Default to `rounded-2xl` (16px / 1rem) to form smooth, modern visual enclosures for dense data.
- **Interactive Buttons & Inputs:** Styled with `rounded-xl` (12px / 0.75rem) to ensure a distinct tactile identity compared to surrounding containment cards.
- **Tags, Stock Chips & Status Pills:** Full circular caps (`rounded-full` / 9999px) to clearly isolate metadata tags from structural, rectangular data panels.
- **Bottom Sheets & Modal Trays:** Top corners anchored with `rounded-t-2xl` (24px) for seamless transition into mobile hardware edges.

## Components

### Metric & KPI Cards
- Base surface is crisp white with `rounded-2xl`, paired with internal padding of `space-md` (16px).
- Displays category tag at top-left, micro trend pill (e.g., `+18.4%` in tertiary emerald on emerald-50 fill) at top-right.
- Large numerical readout using `metric-display` in `#0F172A`, followed by small secondary subtitle in `#64748B`.

### Status Badges & Inventory Chips
- Compact pills utilizing `rounded-full` with vertical padding of 3px and horizontal padding of 8px.
- **In Stock / Active:** `#10B981` text over `#ECFDF5` background.
- **Low Stock / Rate Limit Alert:** `#D97706` text over `#FEF3C7` background.
- **Critical / Out of Stock:** `#DC2626` text over `#FEE2E2` background.
- **Draft / Inactive:** `#475569` text over `#F1F5F9` background.

### Buttons & Interactive Controls
- **Primary Action:** Solid `#4F46E5` background, `#FFFFFF` text, `rounded-xl`, 48px height, subtle internal glow on press.
- **Secondary Action:** `#F1F5F9` background, `#1E293B` text, `rounded-xl`, 48px height.
- **Ghost/Tertiary:** Transparent fill with `#4F46E5` text, for contextual secondary choices inside cards.

### Input Fields & Search Bars
- Single-line search bar features a leading 18px magnifying glass icon in `#64748B`.
- Container uses `#FFFFFF` fill with `1px solid #E2E8F0` border, `rounded-xl`, height of 46px.
- Focus state shifts border color to `#4F46E5` with an external ring of `0 0 0 3px rgba(79, 70, 229, 0.12)`.
- Embedded clear trigger and trailing filter affordance button.

### Segmented Controls (Tab Switchers)
- Surface enclosure in `#F1F5F9` with `rounded-xl` and 4px internal padding.
- Sliding active pill in `#FFFFFF` with `rounded-lg` and subtle micro-shadow (`0 1px 3px rgba(0,0,0,0.08)`).
- Active label set to `#0F172A` semi-bold; inactive states rendered in `#64748B`.

### Bottom Navigation Bar
- Frosted translucent slate-white surface (`#FFFFFF` at 92% opacity with `backdrop-blur(16px)`).
- Bounded by a top hairline border (`#E2E8F0`).
- Equal 5-column layout for: Overview, Inventory, Sales, CRM, Settings.
- Active items illuminate with `#4F46E5` icon fill and matching 4px pill indicator dot positioned underneath.